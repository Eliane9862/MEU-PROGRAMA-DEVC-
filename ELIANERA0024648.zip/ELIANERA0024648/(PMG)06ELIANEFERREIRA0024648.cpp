	#include<stdio.h>
	#include<stdlib.h>
	#include<locale.h>
	int main (){
	setlocale(LC_ALL,"portuguese");
	float numero;
	printf("\nDigite o numero:");
	scanf("%f", &numero);
	if(numero >0 ){
		printf("\nO numero %.2f � possitivo!!!:",numero);	
	}
	else if (numero < 0){
	printf("\nO numero %.2f � negativo:",numero);	
	}
	else{
	printf("\nNumero � zeroooo!!!\n0");
	}
	return 0;
	}
