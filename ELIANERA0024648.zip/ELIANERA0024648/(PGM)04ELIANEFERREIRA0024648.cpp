	#include<stdio.h>
	#include<stdlib.h>
	#include<locale.h>
	int main(){
	setlocale(LC_ALL,"portuguese");	
	//Calcule a m�dia, km e consumo.
	float media, km, consumo;
	printf("\nQual a distancia percorrida do automov�l: ");
	scanf("%f",&km);
	printf("\nQualcule o total do conbustiv�l gastos:");
    scanf("%f",&consumo);
	media = km / consumo;
    printf("\nConsumo total gasto �:%.2f\n",media);
	return 0;
}
