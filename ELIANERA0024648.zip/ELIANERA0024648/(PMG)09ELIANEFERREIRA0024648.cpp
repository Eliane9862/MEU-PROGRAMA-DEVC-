		#include <stdio.h>
		#include <stdlib.h>
		#include <locale.h>
	    int main() {
		setlocale(LC_ALL, "Portuguese");
		//PMG09 verifica��o dos numeros pares, impares.
	    int numero;
	    printf("Digite um n�mero inteiro: ");
	    scanf("%d", &numero);
	    if (numero % 2 == 0) {
        printf("\nO n�mero %d � PAR! \n", numero);
	    } 
	    else {
        printf("\nO n�mero %d � �MPAR! \n", numero);
	    }
	    return 0;
		}
